-- MariaDB dump 10.19  Distrib 10.6.12-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: khl
-- ------------------------------------------------------
-- Server version	10.6.12-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'Baileyfurt',77.35676,72.35676,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(2,'South Sierra',77.35676,72.35676,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(3,'West Gideonberg',77.35676,72.35676,'2023-05-14 18:00:51','2023-05-14 18:00:51');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `club_players`
--

DROP TABLE IF EXISTS `club_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `club_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `player_id` bigint(20) unsigned NOT NULL,
  `season_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_players_club_id_player_id_season_id_unique` (`club_id`,`player_id`,`season_id`),
  KEY `club_players_player_id_foreign` (`player_id`),
  KEY `club_players_season_id_foreign` (`season_id`),
  KEY `club_players_club_id_index` (`club_id`),
  CONSTRAINT `club_players_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `club_players_player_id_foreign` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE,
  CONSTRAINT `club_players_season_id_foreign` FOREIGN KEY (`season_id`) REFERENCES `seasons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `club_players`
--

LOCK TABLES `club_players` WRITE;
/*!40000 ALTER TABLE `club_players` DISABLE KEYS */;
INSERT INTO `club_players` VALUES (1,3,1,1,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(2,1,2,2,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(3,1,3,1,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(4,1,4,2,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(5,2,5,2,'2023-05-14 18:00:52','2023-05-14 18:00:52');
/*!40000 ALTER TABLE `club_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clubs`
--

DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clubs_city_id_foreign` (`city_id`),
  CONSTRAINT `clubs_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clubs`
--

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` VALUES (1,'nihilclub',1,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(2,'sapienteclub',2,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(3,'ullamclub',3,'2023-05-14 18:00:51','2023-05-14 18:00:51');
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `version` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('20230514162005'),('20230514164820'),('20230514165343'),('20230514165630'),('20230514165632'),('20230514165718'),('20230514173349');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `second_name` varchar(255) NOT NULL,
  `weight` bigint(20) unsigned NOT NULL,
  `height` bigint(20) unsigned NOT NULL,
  `number` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (1,'f_player_1','l_player_1','s_player_1',86,178,1,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(2,'f_player_2','l_player_2','s_player_2',80,173,2,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(3,'f_player_3','l_player_3','s_player_3',95,190,3,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(4,'f_player_4','l_player_4','s_player_4',91,175,4,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(5,'f_player_5','l_player_5','s_player_5',60,189,5,'2023-05-14 18:00:52','2023-05-14 18:00:52');
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seasons`
--

DROP TABLE IF EXISTS `seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seasons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stage` enum('regular','playoff','final') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seasons`
--

LOCK TABLES `seasons` WRITE;
/*!40000 ALTER TABLE `seasons` DISABLE KEYS */;
INSERT INTO `seasons` VALUES (1,'regular','2020-04-20','2020-05-20','2023-05-14 18:00:51','2023-05-14 18:00:51'),(2,'regular','2021-04-20','2021-05-20','2023-05-14 18:00:51','2023-05-14 18:00:51');
/*!40000 ALTER TABLE `seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translation_fields`
--

DROP TABLE IF EXISTS `translation_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translation_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `translation_id` bigint(20) unsigned DEFAULT NULL,
  `field` varchar(255) NOT NULL,
  `translate` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translation_fields_translation_id_field_unique` (`translation_id`,`field`),
  CONSTRAINT `translation_fields_translation_id_foreign` FOREIGN KEY (`translation_id`) REFERENCES `translations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translation_fields`
--

LOCK TABLES `translation_fields` WRITE;
/*!40000 ALTER TABLE `translation_fields` DISABLE KEYS */;
INSERT INTO `translation_fields` VALUES (1,1,'name','Город 005','2023-05-14 18:00:51','2023-05-14 18:00:51'),(2,2,'name','Клуб 948','2023-05-14 18:00:51','2023-05-14 18:00:51'),(3,3,'name','Город 640','2023-05-14 18:00:51','2023-05-14 18:00:51'),(4,4,'name','Клуб 331','2023-05-14 18:00:51','2023-05-14 18:00:51'),(5,5,'name','Город 080','2023-05-14 18:00:51','2023-05-14 18:00:51'),(6,6,'name','Клуб 247','2023-05-14 18:00:51','2023-05-14 18:00:51'),(7,7,'first_name','Имя игрока 1','2023-05-14 18:00:52','2023-05-14 18:00:52'),(8,7,'last_name','Фамилия игрока 1','2023-05-14 18:00:52','2023-05-14 18:00:52'),(9,7,'second_name','Отчество игрока 1','2023-05-14 18:00:52','2023-05-14 18:00:52'),(10,8,'first_name','Имя игрока 2','2023-05-14 18:00:52','2023-05-14 18:00:52'),(11,8,'last_name','Фамилия игрока 2','2023-05-14 18:00:52','2023-05-14 18:00:52'),(12,8,'second_name','Отчество игрока 2','2023-05-14 18:00:52','2023-05-14 18:00:52'),(13,9,'first_name','Имя игрока 3','2023-05-14 18:00:52','2023-05-14 18:00:52'),(14,9,'last_name','Фамилия игрока 3','2023-05-14 18:00:52','2023-05-14 18:00:52'),(15,9,'second_name','Отчество игрока 3','2023-05-14 18:00:52','2023-05-14 18:00:52'),(16,10,'first_name','Имя игрока 4','2023-05-14 18:00:52','2023-05-14 18:00:52'),(17,10,'last_name','Фамилия игрока 4','2023-05-14 18:00:52','2023-05-14 18:00:52'),(18,10,'second_name','Отчество игрока 4','2023-05-14 18:00:52','2023-05-14 18:00:52'),(19,11,'first_name','Имя игрока 5','2023-05-14 18:00:52','2023-05-14 18:00:52'),(20,11,'last_name','Фамилия игрока 5','2023-05-14 18:00:52','2023-05-14 18:00:52'),(21,11,'second_name','Отчество игрока 5','2023-05-14 18:00:52','2023-05-14 18:00:52');
/*!40000 ALTER TABLE `translation_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `translatable_type` varchar(255) NOT NULL,
  `translatable_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translations_translatable_id_translatable_type_language_unique` (`translatable_id`,`translatable_type`,`language`),
  KEY `by_informable_type_id` (`translatable_type`,`translatable_id`),
  KEY `language_translatable_type_id` (`language`,`translatable_type`,`translatable_id`),
  KEY `translations_language_index` (`language`),
  KEY `translations_translatable_type_index` (`translatable_type`),
  KEY `translations_translatable_id_index` (`translatable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
INSERT INTO `translations` VALUES (1,'ru','App\\Models\\City',1,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(2,'ru','App\\Models\\Club',1,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(3,'ru','App\\Models\\City',2,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(4,'ru','App\\Models\\Club',2,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(5,'ru','App\\Models\\City',3,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(6,'ru','App\\Models\\Club',3,'2023-05-14 18:00:51','2023-05-14 18:00:51'),(7,'ru','App\\Models\\Player',1,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(8,'ru','App\\Models\\Player',2,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(9,'ru','App\\Models\\Player',3,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(10,'ru','App\\Models\\Player',4,'2023-05-14 18:00:52','2023-05-14 18:00:52'),(11,'ru','App\\Models\\Player',5,'2023-05-14 18:00:52','2023-05-14 18:00:52');
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-14 21:10:54
